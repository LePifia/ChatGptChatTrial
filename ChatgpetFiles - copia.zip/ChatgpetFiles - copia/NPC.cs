using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC : MonoBehaviour
{
    [TextArea] public string physicalDescription;
    [TextArea] public string personality;
    [TextArea] public string locationDescription;
    [TextArea] public string[] knowledgeAboutLife;

}
