using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using OpenAI;
using Unity.VisualScripting;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    private OpenAIApi aIApi = new OpenAIApi();
    private List<ChatMessage> messages = new List<ChatMessage>();

    [SerializeField] NPC currentNpc;
    [SerializeField][TextArea(minLines: 5, maxLines: 10)] string dialogueRules;

    [Space]
    [Header("Components")]

    [SerializeField] GameObject dialogueCanvas;
    [SerializeField] GameObject playerUI;
    [SerializeField] TMP_Text npcDialogueText;
    [SerializeField] TMP_InputField playerInput;

    public bool IsTalking;


    private void Start()
    {
        DialogueRequest("");
    }

    public void StartDialogue(NPC npc)
    {

        IsTalking = true;
        currentNpc = npc;
        dialogueCanvas.SetActive(true);
        Time.timeScale = 0.0f;
        messages.Clear();

        DialogueRequest("");
    }

    public void EndDialogue()
    {
        currentNpc = null;
        dialogueCanvas.SetActive(false);
        Time.timeScale = 1.0f;
        messages.Clear();
    }

    async void DialogueRequest (string playerMessage)
    {
        //UpdateUI
        npcDialogueText.text = "Hmmm...";
        playerInput.text = string.Empty;
        playerUI.SetActive(false);
        
        
        var message = new ChatMessage()
        {
            Role = "user",
            Content = playerMessage
        };

        if (messages.Count == 0 ) {

            message.Content = $"Act as as {currentNpc.physicalDescription} in a bar." +
                    $"As a character, you are {currentNpc.personality}." +
                    $"Your location is {currentNpc.locationDescription}." +
                    $"You have some knowledge that you will speak about if asked for advice and it is relevant for the conversation:" +
                    $"{currentNpc.knowledgeAboutLife}. \n {dialogueRules} ";


        }

        messages.Add(message);

        var request = new CreateChatCompletionRequest
        {
            Model = "gpt-3.5-turbo",
            Messages = messages
        };

        var response = await aIApi.CreateChatCompletion(request);

        if (response.Choices != null)
        {
            ChatMessage responseMessage = response.Choices[0].Message;
            messages.Add(responseMessage);

            npcDialogueText.text = responseMessage.Content;
        }

        playerUI.SetActive(true);


    }

    public void OnTalkButton()
    {
        DialogueRequest(playerInput.text);
    }

}
